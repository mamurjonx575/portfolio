// Portfolio Website JavaScript

// EmailJS Configuration
// EmailJS hizmatini sozlash uchun quyidagi qadamlarni bajaring:
// 1. https://www.emailjs.com/ saytiga kiring va ro'yxatdan o'ting
// 2. Email xizmatini qo'shing (Gmail, Outlook va boshqalar)
// 3. Email template yarating
// 4. Quyidagi ma'lumotlarni o'zingizniki bilan almashtiring:

const EMAILJS_CONFIG = {
    serviceID: 'service_ip4vwgb',        // EmailJS Service ID ni bu yerga kiriting
    templateID: 'template_grm1733',      // EmailJS Template ID ni bu yerga kiriting
    publicKey: 'u5Dvm_Y5bjvK2exkK'         // EmailJS Public Key ni bu yerga kiriting
};

// EmailJS ni initialize qilish
function initEmailJS() {
    // EmailJS kutubxonasi yuklanganini tekshirish
    if (typeof emailjs !== 'undefined') {
        emailjs.init(EMAILJS_CONFIG.publicKey);
        console.log('EmailJS muvaffaqiyatli yuklandi');
    }
}

// Sahifa yuklanganda EmailJS ni ishga tushirish
window.addEventListener('load', initEmailJS);

// Smooth scrolling for navigation links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Header scroll effect
let lastScroll = 0;

window.addEventListener('scroll', () => {
    const header = document.querySelector('header');
    const currentScroll = window.pageYOffset;
    
    // Add shadow when scrolled
    if (currentScroll > 100) {
        header.style.boxShadow = '0 2px 20px rgba(0, 0, 0, 0.5)';
    } else {
        header.style.boxShadow = 'none';
    }
    
    lastScroll = currentScroll;
});

// Form validation and submission
const contactForm = document.getElementById('contactForm');

if (contactForm) {
    contactForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Get form data
        const formData = new FormData(this);
        const data = {
            name: formData.get('name'),
            email: formData.get('email'),
            phone: formData.get('phone') || 'Kiritilmagan',
            subject: formData.get('subject'),
            budget: formData.get('budget') || 'Tanlanmagan',
            message: formData.get('message')
        };
        
        // Validate email
        if (!isValidEmail(data.email)) {
            showNotification('Iltimos, to\'g\'ri email manzilini kiriting', 'error');
            return;
        }
        
        // Validate message length
        if (data.message.length < 10) {
            showNotification('Xabar kamida 10 ta belgidan iborat bo\'lishi kerak', 'error');
            return;
        }
        
        // Submit form with EmailJS
        submitFormWithEmailJS(data, this);
    });
}

// Email validation function
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Form submission with EmailJS
function submitFormWithEmailJS(data, form) {
    // Show loading state
    const submitButton = document.querySelector('.submit-button');
    const originalHTML = submitButton.innerHTML;
    submitButton.innerHTML = '<span>Yuborilmoqda...</span>';
    submitButton.disabled = true;
    
    // EmailJS orqali email yuborish
    if (typeof emailjs !== 'undefined') {
        // EmailJS template uchun parametrlar
        const templateParams = {
            from_name: data.name,
            from_email: data.email,
            phone: data.phone,
            subject: data.subject,
            budget: data.budget,
            message: data.message,
            to_email: 'mamurjonx575@gmail.com' // Sizning emailingiz
        };
        
        // EmailJS orqali yuborish
        emailjs.send(
            EMAILJS_CONFIG.serviceID,
            EMAILJS_CONFIG.templateID,
            templateParams
        ).then(
            function(response) {
                console.log('Email muvaffaqiyatli yuborildi!', response.status, response.text);
                
                // Reset button
                submitButton.innerHTML = originalHTML;
                submitButton.disabled = false;
                
                // Show success message
                showNotification('Xabaringiz uchun rahmat! Tez orada siz bilan bog\'lanamiz.', 'success');
                
                // Reset form
                form.reset();
            },
            function(error) {
                console.error('Email yuborishda xatolik:', error);
                
                // Reset button
                submitButton.innerHTML = originalHTML;
                submitButton.disabled = false;
                
                // Show error message
                showNotification('Xatolik yuz berdi. Iltimos, qaytadan urinib ko\'ring yoki to\'g\'ridan-to\'g\'ri email orqali bog\'laning.', 'error');
            }
        );
    } else {
        // EmailJS yuklanmagan bo'lsa, oddiy simulyatsiya
        console.warn('EmailJS yuklanmagan. Demo rejimda ishlamoqda.');
        
        setTimeout(() => {
            // Reset button
            submitButton.innerHTML = originalHTML;
            submitButton.disabled = false;
            
            // Show demo message
            showNotification('Demo rejim: Xabar qabul qilindi. Real email yuborish uchun EmailJS ni sozlang.', 'success');
            
            // Reset form
            form.reset();
            
            // Log data for demo
            console.log('Yuborilgan ma\'lumotlar:', data);
        }, 1500);
    }
}

// Notification function
function showNotification(message, type = 'success') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    
    // Style the notification
    Object.assign(notification.style, {
        position: 'fixed',
        top: '20px',
        right: '20px',
        padding: '1.2rem 2rem',
        background: type === 'success' ? 'var(--accent-gold)' : '#e74c3c',
        color: type === 'success' ? 'var(--primary-dark)' : '#fff',
        borderRadius: '4px',
        boxShadow: '0 4px 20px rgba(0, 0, 0, 0.3)',
        zIndex: '10000',
        animation: 'slideInRight 0.3s ease-out',
        maxWidth: '400px',
        fontFamily: 'Montserrat, sans-serif',
        fontSize: '0.9rem',
        letterSpacing: '0.5px',
        fontWeight: '500'
    });
    
    // Add to page
    document.body.appendChild(notification);
    
    // Remove after 6 seconds
    setTimeout(() => {
        notification.style.animation = 'slideOutRight 0.3s ease-out';
        setTimeout(() => {
            notification.remove();
        }, 300);
    }, 6000);
}

// Add notification animations to the page
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from {
            transform: translateX(400px);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOutRight {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(400px);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

// Gallery item click handlers
const galleryItems = document.querySelectorAll('.gallery-item');

galleryItems.forEach((item, index) => {
    item.addEventListener('click', function() {
        const title = this.querySelector('h3').textContent;
        const description = this.querySelector('p').textContent;
        
        console.log('Loyiha:', title, '-', description);
    });
});

// Add hover effect for service cards
const serviceCards = document.querySelectorAll('.service-card');

serviceCards.forEach(card => {
    card.addEventListener('mouseenter', function() {
        this.style.boxShadow = '0 10px 40px rgba(212, 175, 55, 0.2)';
    });
    
    card.addEventListener('mouseleave', function() {
        this.style.boxShadow = 'none';
    });
});

// Active navigation link on scroll
const sections = document.querySelectorAll('section[id]');
const navLinks = document.querySelectorAll('.nav-links a');

window.addEventListener('scroll', () => {
    let current = '';
    
    sections.forEach(section => {
        const sectionTop = section.offsetTop;
        const sectionHeight = section.clientHeight;
        
        if (window.pageYOffset >= sectionTop - 200) {
            current = section.getAttribute('id');
        }
    });
    
    navLinks.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === `#${current}`) {
            link.classList.add('active');
        }
    });
});

// Add active class styling
const activeStyle = document.createElement('style');
activeStyle.textContent = `
    .nav-links a.active {
        color: var(--accent-gold);
    }
    
    .nav-links a.active::after {
        width: 100%;
    }
`;
document.head.appendChild(activeStyle);

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    console.log('Portfolio veb-sayti muvaffaqiyatli yuklandi');
    
    // Add fade-in animation to elements
    const animateElements = document.querySelectorAll('.service-card, .gallery-item');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.animation = 'fadeInUp 0.6s ease-out forwards';
                entry.target.style.opacity = '0';
                observer.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.1
    });
    
    animateElements.forEach(el => {
        observer.observe(el);
    });
});